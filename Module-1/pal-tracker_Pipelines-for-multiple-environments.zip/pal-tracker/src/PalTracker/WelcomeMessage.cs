namespace PalTracker
{
    
    public class WelcomeMessage
    {
        public string message ;

        public WelcomeMessage( string msg_arg)
        {
            message = msg_arg;
        }
    }
}