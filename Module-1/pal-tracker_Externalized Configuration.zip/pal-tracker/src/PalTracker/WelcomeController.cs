using Microsoft.AspNetCore.Mvc;

namespace PalTracker
{
    [Route("/")]
    public class WelcomeController : ControllerBase
    {
        WelcomeMessage welcomemsg;

        public WelcomeController(WelcomeMessage welmsg_arg)
        {
            welcomemsg = welmsg_arg;
        }
        [HttpGet()]
        public string SayHello() 
        {
            System.Diagnostics.Debug.WriteLine("#####  WelcomeController.SayHello() ");
            return welcomemsg.message;
        } 
    }
}
